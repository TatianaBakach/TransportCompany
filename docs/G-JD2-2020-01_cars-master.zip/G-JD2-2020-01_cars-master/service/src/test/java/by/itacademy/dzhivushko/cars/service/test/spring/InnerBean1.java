package by.itacademy.dzhivushko.cars.service.test.spring;

public class InnerBean1 {

}
