package by.itacademy.dzhivushko.cars.dao.api.entity.enums;

public enum EngineType {
	diesel, gasoline

}
