package by.itacademy.dzhivushko.cars.dao.api.filter;

public class BrandFilter extends AbstractFilter {

}
