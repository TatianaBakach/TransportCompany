package by.itacademy.dzhivushko.cars.dao.api;

import by.itacademy.dzhivushko.cars.dao.api.entity.table.IModelInfo;

public interface IModelInfoDao extends IDao<IModelInfo, Integer> {
}
