package by.itacademy.dzhivushko.cars.dao.api.entity.table;

public interface IBrand extends IBaseEntity {

    String getName();

    void setName(String name);

}
