package by.itacademy.dzhivushko.cars.web.dto;

public class ModelInfoDTO {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}
