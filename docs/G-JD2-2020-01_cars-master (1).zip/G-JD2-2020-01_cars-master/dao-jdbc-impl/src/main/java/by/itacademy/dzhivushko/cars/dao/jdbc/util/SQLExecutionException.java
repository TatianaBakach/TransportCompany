package by.itacademy.dzhivushko.cars.dao.jdbc.util;

public class SQLExecutionException extends RuntimeException {

    public SQLExecutionException(final Exception cause) {
        super(cause);
    }

}
